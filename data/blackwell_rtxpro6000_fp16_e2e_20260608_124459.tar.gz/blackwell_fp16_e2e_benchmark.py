import argparse
import csv
import json
import statistics
import time
import threading
from pathlib import Path

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

try:
    import pynvml
except ImportError:
    pynvml = None


def sample_power(stop_event, samples, interval_s=0.01, gpu_index=0):
    if pynvml is None:
        return

    pynvml.nvmlInit()
    handle = pynvml.nvmlDeviceGetHandleByIndex(gpu_index)

    while not stop_event.is_set():
        t = time.perf_counter()
        try:
            power_w = pynvml.nvmlDeviceGetPowerUsage(handle) / 1000.0
            samples.append((t, power_w))
        except Exception:
            pass
        time.sleep(interval_s)


def integrate_energy(samples, start_t, end_t):
    window = [(t, p) for t, p in samples if start_t <= t <= end_t]
    if len(window) < 2:
        return None, None, None

    energy_j = 0.0
    for (t0, p0), (t1, p1) in zip(window[:-1], window[1:]):
        energy_j += ((p0 + p1) / 2.0) * (t1 - t0)

    powers = [p for _, p in window]
    return energy_j, sum(powers) / len(powers), max(powers)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", default="/root/autodl-tmp/models/Qwen2.5-3B-Instruct")
    parser.add_argument("--outdir", default="/root/autodl-tmp/blackwell_e2e_fp16/results")
    parser.add_argument("--tokens", nargs="+", type=int, default=[256, 512])
    parser.add_argument("--batch", type=int, default=1)
    parser.add_argument("--runs", type=int, default=10)
    parser.add_argument("--warmup", type=int, default=2)
    parser.add_argument("--prompt-len", type=int, default=128)
    parser.add_argument("--gpu-index", type=int, default=0)
    parser.add_argument("--power-interval", type=float, default=0.01)
    args = parser.parse_args()

    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    print("=== Blackwell RTX PRO 6000 FP16 E2E Benchmark ===")
    print("model:", args.model)
    print("batch:", args.batch)
    print("tokens:", args.tokens)
    print("runs:", args.runs)
    print("warmup:", args.warmup)
    print("torch:", torch.__version__)
    print("cuda:", torch.version.cuda)
    print("device:", torch.cuda.get_device_name(0))
    print("capability:", torch.cuda.get_device_capability(0))

    tokenizer = AutoTokenizer.from_pretrained(args.model, trust_remote_code=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    model = AutoModelForCausalLM.from_pretrained(
        args.model,
        torch_dtype=torch.float16,
        device_map="cuda",
        trust_remote_code=True,
    )
    model.eval()

    base_text = "Explain the energy efficiency trade-offs of LLM quantization in one concise technical paragraph. "
    repeated = (base_text * 64).strip()

    encoded = tokenizer(
        repeated,
        return_tensors="pt",
        truncation=True,
        max_length=args.prompt_len,
        padding=False,
    )

    input_ids = encoded["input_ids"].repeat(args.batch, 1).to("cuda")
    attention_mask = encoded["attention_mask"].repeat(args.batch, 1).to("cuda")

    rows = []

    meta = {
        "model": args.model,
        "precision": "FP16",
        "batch": args.batch,
        "tokens": args.tokens,
        "runs": args.runs,
        "warmup": args.warmup,
        "prompt_len": int(input_ids.shape[1]),
        "torch": torch.__version__,
        "cuda_runtime": torch.version.cuda,
        "gpu_name": torch.cuda.get_device_name(0),
        "gpu_capability": torch.cuda.get_device_capability(0),
        "pynvml_available": pynvml is not None,
    }

    with open(outdir / "metadata.json", "w", encoding="utf-8") as f:
        json.dump(meta, f, indent=2)

    for max_new_tokens in args.tokens:
        print(f"\n--- max_new_tokens={max_new_tokens} ---")

        for i in range(args.warmup):
            with torch.inference_mode():
                _ = model.generate(
                    input_ids=input_ids,
                    attention_mask=attention_mask,
                    max_new_tokens=max_new_tokens,
                    do_sample=False,
                    use_cache=True,
                    pad_token_id=tokenizer.eos_token_id,
                )
            torch.cuda.synchronize()
            print(f"warmup {i + 1}/{args.warmup} done")

        run_rows = []

        for run_idx in range(args.runs):
            torch.cuda.empty_cache()
            torch.cuda.synchronize()

            samples = []
            stop_event = threading.Event()
            sampler = threading.Thread(
                target=sample_power,
                args=(stop_event, samples, args.power_interval, args.gpu_index),
                daemon=True,
            )

            sampler.start()
            time.sleep(0.1)

            start_t = time.perf_counter()
            with torch.inference_mode():
                output = model.generate(
                    input_ids=input_ids,
                    attention_mask=attention_mask,
                    max_new_tokens=max_new_tokens,
                    do_sample=False,
                    use_cache=True,
                    pad_token_id=tokenizer.eos_token_id,
                )
            torch.cuda.synchronize()
            end_t = time.perf_counter()

            stop_event.set()
            sampler.join(timeout=1.0)

            elapsed_s = end_t - start_t
            generated_tokens = int((output.shape[1] - input_ids.shape[1]) * args.batch)
            throughput = generated_tokens / elapsed_s if elapsed_s > 0 else None

            energy_j, avg_power_w, peak_power_w = integrate_energy(samples, start_t, end_t)
            energy_per_1k = (energy_j / generated_tokens * 1000.0) if energy_j is not None and generated_tokens > 0 else None

            row = {
                "precision": "FP16",
                "batch": args.batch,
                "prompt_tokens_per_sample": int(input_ids.shape[1]),
                "max_new_tokens": max_new_tokens,
                "run": run_idx + 1,
                "generated_tokens_total": generated_tokens,
                "elapsed_s": elapsed_s,
                "throughput_tok_s": throughput,
                "energy_j": energy_j,
                "energy_per_1k_tokens_j": energy_per_1k,
                "avg_power_w": avg_power_w,
                "peak_power_w": peak_power_w,
                "power_samples": len(samples),
            }

            rows.append(row)
            run_rows.append(row)

            print(
                f"run {run_idx + 1}/{args.runs}: "
                f"{throughput:.2f} tok/s, "
                f"{elapsed_s:.2f}s, "
                f"energy={energy_j}, "
                f"J/1k={energy_per_1k}"
            )

        valid_tp = [r["throughput_tok_s"] for r in run_rows if r["throughput_tok_s"] is not None]
        valid_e = [r["energy_per_1k_tokens_j"] for r in run_rows if r["energy_per_1k_tokens_j"] is not None]
        valid_p = [r["avg_power_w"] for r in run_rows if r["avg_power_w"] is not None]

        summary = {
            "precision": "FP16",
            "batch": args.batch,
            "max_new_tokens": max_new_tokens,
            "runs": args.runs,
            "throughput_tok_s_mean": statistics.mean(valid_tp) if valid_tp else None,
            "throughput_tok_s_std": statistics.stdev(valid_tp) if len(valid_tp) > 1 else None,
            "energy_per_1k_tokens_j_mean": statistics.mean(valid_e) if valid_e else None,
            "energy_per_1k_tokens_j_std": statistics.stdev(valid_e) if len(valid_e) > 1 else None,
            "avg_power_w_mean": statistics.mean(valid_p) if valid_p else None,
            "avg_power_w_std": statistics.stdev(valid_p) if len(valid_p) > 1 else None,
        }

        with open(outdir / f"summary_fp16_b{args.batch}_tok{max_new_tokens}.json", "w", encoding="utf-8") as f:
            json.dump(summary, f, indent=2)

        print("summary:", json.dumps(summary, indent=2))

    csv_path = outdir / "blackwell_rtxpro6000_fp16_e2e_runs.csv"
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        fieldnames = list(rows[0].keys())
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    print("\nSaved:", csv_path)


if __name__ == "__main__":
    main()
